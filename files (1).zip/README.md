# Rohan Shetye — Personal Site

Personal branding site for Rohan Shetye, Director of Talent Acquisition.

Single self-contained `index.html` — no build step, no dependencies.
Fonts load from Google Fonts; the profile photo is embedded inline.

## Run locally
Open `index.html` in any browser.

## Deploy (GitHub Pages)
1. Push this repo to GitHub
2. Settings → Pages → Source: `main` branch, `/root`
3. Live at `https://<username>.github.io/<repo-name>/`
